var sumaNumeros = (a, b) => a + b
var restaNumeros = (a, b) => a - b
var multiplicaNumeros = (a, b) => a * b
var divideNumeros = (a, b) => a / b

console.log(sumaNumeros(5,3))
console.log(restaNumeros(5,3))
console.log(multiplicaNumeros(5,3))
console.log(divideNumeros(5,3))

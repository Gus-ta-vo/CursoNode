for (let i=0; i<5; i++){
    console.log(i)
}
console.log(i)